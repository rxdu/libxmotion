## Legacy 

TO BE DEPRECATED SOON

Reference:

Quadtree Implementation Reference:

* http://devmag.org.za/2011/02/23/quadtrees-implementation/
* https://github.com/DynamoSchrittmotor/CNC/blob/master/opencv/quadtree.h
* https://gist.github.com/tomasbasham/10545966
* http://www.gamedev.net/page/resources/_/technical/graphics-programming-and-theory/quadtrees-r1303
