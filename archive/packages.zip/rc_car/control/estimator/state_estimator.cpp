/* 
 * state_estimator.cpp
 * 
 * Created on: Oct 31, 2017 22:37
 * 
 * Copyright (c) 2017 Ruixiang Du (rdu)
 */ 

 #include "state_estimator.h"

 using namespace librav;

 StateEstimator::StateEstimator()
 {
     
 }