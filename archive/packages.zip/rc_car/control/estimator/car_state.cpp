/* 
 * car_state.cpp
 * 
 * Created on: Oct 31, 2017 22:32
 * 
 * Copyright (c) 2017 Ruixiang Du (rdu)
 */ 

 #include "car_state.h"

 using namespace librav;

 constexpr double CarParam::wheel_diameter;
 constexpr double CarParam::gear_ratio;

 CarState::CarState()
 {
     
 }