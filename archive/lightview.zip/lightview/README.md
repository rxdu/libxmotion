# lightview

minimal GUI setup for visualization with GUI interactions