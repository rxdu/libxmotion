## Vehicle Visualization

Extension to lightviz package for vehicle applications. This separation is to avoid dependency of lightviz from non-core packages.