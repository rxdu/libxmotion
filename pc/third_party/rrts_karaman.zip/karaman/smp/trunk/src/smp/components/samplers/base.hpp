#ifndef _SMP_SAMPLER_BASE_HPP_
#define _SMP_SAMPLER_BASE_HPP_

#include <smp/components/samplers/base.h>

#include <smp/planner_utils/vertex_edge.hpp>

#endif
