#ifndef _SMP_EXTEND_BASE_HPP_
#define _SMP_EXTEND_BASE_HPP_

#include <smp/components/extenders/base.h>

#include <smp/planner_utils/trajectory.hpp>
#include <smp/planner_utils/vertex_edge.hpp>

#endif
