#ifndef _SMP_MODEL_CHECKER_BASE_HPP_
#define _SMP_MODEL_CHECKER_BASE_HPP_


#include <smp/components/model_checkers/base.h>

#include <smp/planner_utils/trajectory.hpp>
#include <smp/planner_utils/vertex_edge.hpp>


#endif
