#ifndef _SMP_INTERFACE_BASE_HPP_
#define _SMP_INTERFACE_BASE_HPP_

#include <smp/interfaces/base.h>

#include <smp/planners/base.hpp>


#endif
