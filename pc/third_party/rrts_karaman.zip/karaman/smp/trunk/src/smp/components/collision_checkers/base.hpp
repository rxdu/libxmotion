#ifndef _SMP_COLLISION_CHECKER_BASE_HPP_
#define _SMP_COLLISION_CHECKER_BASE_HPP_

#include <smp/components/collision_checkers/base.h>

#include <smp/planner_utils/trajectory.hpp>
#include <smp/planner_utils/vertex_edge.hpp>


#endif
