
/** @mainpage Sampling-based Motion Planning (SMP) Library
*
* @authors Sertac Karaman and Emilio Frazzoli 
*	(Laboratory for Information and Decision Systems, 
*	Massachusetts Institute of Techonology, Cambrdige, MA.)
*
* @section intro Introduction
* 
*
* <hr>
* @section notes Release Notes
* 
* <hr>
* @section requirements Dependencies
* 
* <hr>
* @section license License
*
*/
